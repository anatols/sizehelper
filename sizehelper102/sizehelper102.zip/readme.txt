SizeHelper by Anatoliy Samara.
http://2xsamara.com

SizeHelper is a photoshop extension that adds pixel size indication and size presets to Image Size dialog.

Installation:
Copy sizehelper.8bx and sizehelper.cfg to \Program Files\Adobe\Adobe Photoshop CSx\Plug-ins. Restart Photoshop.

History:
1.02
- Fixed a bug that lowered files size when Constrain Proportions check was on

1.01
- Added config file for presets

1.00
- Pixel size indication in dialog title
- Pixel size preset menu
- 4 types of presets - Mpx count, long edge size, width and height
- Tested with Photoshop CS3 English and CS4 English.

Disclaimer:
This software is provided AS IS without warranties of any kind, either express or implied.
You can use and distribute this software free.

