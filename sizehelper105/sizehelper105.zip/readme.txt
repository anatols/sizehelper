SizeHelper
(c) Anatoliy Samara.
http://2xsamara.com

SizeHelper is a photoshop extension that adds pixel size indication and size presets to Image Size dialog.

Installation:
Copy sizehelper.8bx (or sizehelper64.8bx for 64-bit photoshop) and sizehelper.cfg to \Program Files\Adobe\Adobe Photoshop CSx\Plug-ins.
Please use windows explorer in Vista and Windows 7 to copy the file, third party file managers do not set file permissions properly and Photoshop won't see the plugin.
Restart Photoshop.

History:
1.05
- Once again fixed a bug that lowered files size when Constrain Proportions check was on

1.04
- Popup menu now opens by F10 key

1.03
- Added 64-bit version

1.02
- Fixed a bug that lowered files size when Constrain Proportions check was on

1.01
- Added config file for presets

1.00
- Pixel size indication in dialog title
- Pixel size preset menu
- 4 types of presets - Mpx count, long edge size, width and height
- Tested with Photoshop CS3 English and CS4 English.

Disclaimer:
This software is provided AS IS without warranties of any kind, either express or implied.
You can use and distribute this software free if you keep my copyright.

